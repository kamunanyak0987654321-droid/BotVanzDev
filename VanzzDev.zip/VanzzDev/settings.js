module.exports = {
  prefix: ".",
  ownerName: "Vanz",
  ownerNumber: ["62895365156485"], // HARUS ARRAY
  namebot: "Vanz Botz",
  //API
  deepseekApikey: "sk-1bdf79ba80244688b298728289be6797",
  //Gemini
  geminiApikey: "AIzaSyCBXGaMq8GvzvegYS8R2qzuUwcOO-j4xao"
}