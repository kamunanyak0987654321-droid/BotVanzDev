// features/musicPlayer.js
const axios = require('axios');
const ytdl = require('ytdl-core');

module.exports = async (vanz, m, args) => {
    try {
        const chatId = m.key?.remoteJid || m.chat;
        
        // Jika tidak ada args, default cari "Surat Cinta untuk Starla"
        const searchQuery = args.length > 0 ? args.join(' ') : 'Surat Cinta untuk Starla';
        
        console.log(`🎵 Searching: ${searchQuery}`);
        
        await vanz.sendMessage(chatId, { 
            text: `🔍 *Mencari lagu:*\n"${searchQuery}"\n\n⏳ Tunggu sebentar...` 
        });

        // Cari video di YouTube
        const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}`;
        
        try {
            // Method 1: Coba ambil dari API external
            const apiUrl = `https://api.haikei.xyz/api/ytplay?q=${encodeURIComponent(searchQuery)}`;
            const response = await axios.get(apiUrl);
            
            if (response.data && response.data.result) {
                const videoData = response.data.result;
                
                // Kirim info lagu
                await vanz.sendMessage(chatId, {
                    image: { url: videoData.thumbnail },
                    caption: `🎵 *Lagu Ditemukan!*\n\n📀 Judul: ${videoData.title}\n⏱️ Durasi: ${videoData.duration}\n👤 Channel: ${videoData.channel}\n\n📥 Mengunduh audio...`
                });

                // Kirim audio
                await vanz.sendMessage(chatId, {
                    audio: { url: videoData.audio },
                    mimetype: 'audio/mp4',
                    fileName: `${videoData.title}.mp3`,
                    ptt: false
                });

                return;
            }
        } catch (apiError) {
            console.log('API Error, trying method 2...');
        }

        // Method 2: Alternative API
        try {
            const apiUrl2 = `https://api.lolhuman.xyz/api/ytplay2?apikey=yourkey&query=${encodeURIComponent(searchQuery)}`;
            const response2 = await axios.get(apiUrl2);
            
            if (response2.data && response2.data.result) {
                const video = response2.data.result;
                
                await vanz.sendMessage(chatId, {
                    image: { url: video.thumbnail },
                    caption: `🎵 *${video.title}*\n\n⏱️ ${video.duration}\n📺 ${video.channel}\n\nAudio sedang dikirim...`
                });

                await vanz.sendMessage(chatId, {
                    audio: { url: video.audio },
                    mimetype: 'audio/mp4',
                    fileName: `${video.title}.mp3`
                });

                return;
            }
        } catch (apiError2) {
            console.log('API 2 Error');
        }

        // Method 3: Fallback - kirim link search
        await vanz.sendMessage(chatId, {
            text: `🎵 *Lagu:* "${searchQuery}"\n\n🔗 *Link Pencarian:*\n${searchUrl}\n\n⚠️ Bot sedang maintenance fitur download. Silakan buka link di atas untuk mendengarkan.`
        });

    } catch (error) {
        console.error("Music Player Error:", error);
        const chatId = m.key?.remoteJid || m.chat;
        
        await vanz.sendMessage(chatId, { 
            text: `❌ Gagal memutar lagu:\n"${args.join(' ') || 'Surat Cinta untuk Starla'}"\n\nError: ${error.message}` 
        });
    }
};